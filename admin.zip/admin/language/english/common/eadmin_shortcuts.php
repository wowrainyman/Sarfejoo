<?php
$_['text_eadmin_products']			= 'Products';
$_['text_eadmin_categories']		= 'Categories';
$_['text_eadmin_manufacturer']		= 'Manufacturers';
$_['text_eadmin_information']		= 'Information';
$_['text_eadmin_reviews']			= 'Reviews';
$_['text_eadmin_orders']			= 'Orders';
$_['text_eadmin_returns']			= 'Returns';
$_['text_eadmin_customers']			= 'Customers';
$_['text_eadmin_mail']				= 'Newsletter';
$_['text_eadmin_settings']			= 'Settings';
$_['text_eadmin_purchased']			= 'Purchased';
$_['text_eadmin_backup_restore']	= 'Backup';
?>