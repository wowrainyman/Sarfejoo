<?php	
define ("password", "11625067");
define ("username", "01205638");
?>